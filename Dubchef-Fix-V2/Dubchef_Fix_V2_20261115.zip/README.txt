Dubchef fix V2 for YiTang-159/CNPM, base commit 57a5fad.
Extract this ZIP into a separate folder, then run:
powershell -ExecutionPolicy Bypass -File .\Apply-Upgrade.ps1 -RepositoryPath "C:\Users\Ngan\Documents\GitHub\CNPM"
The script checks conflicts and backs up source files. It does not overwrite .env, .git, SQL or Docker volumes.
After applying, read docs/SUA_LOI_VA_NGHIEM_THU_V2.md in CNPM, commit and push to run CI again.
No new npm dependencies are required by V2.
