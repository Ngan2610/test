> **Sửa kiến trúc/CD V2:** [Áp dụng và nghiệm thu](docs/SUA_LOI_VA_NGHIEM_THU_V2.md). Các controller dùng service; có kiểm tra Windows, APK artifact và script xác minh 13 file xuất. Cần CI và cấu hình triển khai thật của nhóm để chốt nghiệm thu.

> **Bản hoàn thiện:** Xem [hướng dẫn Windows và CI/CD](docs/HOAN_THIEN_VA_CAI_DAT_WINDOWS.md) và [kết quả nghiệm thu](docs/BAO_CAO_NGHIEM_THU_20261115.md). Có server STT, xuất MP4 nhiều audio track, thư viện Mobile và CD Docker Desktop. Các báo cáo cũ không thay thế kết quả nghiệm thu mới.

> **Bản nâng cấp CNPM(5), 15/11/2026:** Đã tích hợp API job, worker SQL độc lập, Render microservice, xuất MP3/MP4/SRT/VTT và theo dõi tiến độ. Đọc [báo cáo nâng cấp](docs/NANG_CAP_CNM5_2026-11-15.md) và [kịch bản demo được hiệu chỉnh](docs/HUONG_DAN_DEMO_GIANG_VIEN.md). STT vẫn ở Web/Mobile; chưa nghiệm thu end-to-end Docker/video thật. Trên máy Windows dùng API `http://localhost:4000` (nội bộ Docker `api:3000`), giữ `.env` và dữ liệu SQL cũ.

[![CI](https://github.com/YiTang-159/CNPM/actions/workflows/ci.yml/badge.svg)](https://github.com/YiTang-159/CNPM/actions/workflows/ci.yml)

# Dubchef thuyết minh video đa ngôn ngữ

> **Lưu ý nâng cấp CSDL (15/11/2026):** Migrations giờ chạy theo một danh sách ở `server/src/migrationPlan.mjs` và có SHA-256 trong `SchemaMigrations`; Docker có bước `migrate` riêng trước API. **ĐỪNG áp dụng trực tiếp vào DubchefDB đang có dữ liệu** trước khi sao lưu/khôi phục thử vào staging và chạy `db/tests/preflight-existing.sql`. Xem `docs/DATABASE.md`, `docs/DATA_DICTIONARY.md`, `docs/DB_AUDIT_REPORT.md`. Một số migration chủ động THROW khi phát hiện đơn hàng/giao dịch lịch sử mâu thuẫn; không xóa hoặc tự sửa tiền. Không dùng `docker compose down -v`.


Bản thống nhất React Web, React Native Mobile, Node Express và SQL Server. Bộ sơ đồ UC Activity DFD nằm trong `docs/so-do`; tài liệu đã cập nhật là `docs/Dubchef_FocusedUseCases.docx`.

## Chạy trên máy Windows

1. Mở Docker Desktop, mở terminal tại thư mục có `docker-compose.yml`.
2. Chạy `npm run setup:local`. Máy mới sẽ được tạo mật khẩu SQL/Admin và token ngẫu nhiên trong `.env`. Máy đã có `.env` chỉ bổ sung biến còn thiếu, không tự thay mật khẩu SQL đã lưu. **Nếu dùng dữ liệu cũ, đọc `docs/BAO_MAT_VA_CHIA_SE.md` trước.**
3. Chạy `docker compose up -d --build`.
4. Mở `http://localhost:3000/api/health`: cần `ok: true`, `db: true`.
5. Dùng Node.js 22.12 trở lên trong dòng 22. Chạy `npm ci --prefix web`, sau đó `npm run web`. Mở `http://localhost:5173`.
6. SSMS kết nối `localhost,1433`, SQL Server Authentication với thông tin SQL hiện tại; chọn `DubchefDB`. Chạy `db/queries.sql` để xem tổng hợp.

Không chạy `docker compose down -v` khi muốn giữ dữ liệu. Khi cập nhật, giải nén vào thư mục mới và dùng lại `.env` cũ; không chép `node_modules` hoặc `dist` từ bản cũ.

`web/.env` dùng `/backend` qua Vite proxy đến API cổng 3000. Bảo mật mặc định chỉ công bố cổng 3000/1433 trên `127.0.0.1`; muốn truy cập từ điện thoại hoặc máy khác phải cấu hình rõ `API_BIND_ADDRESS`/`DB_BIND_ADDRESS`, CORS và Firewall theo tài liệu bảo mật. Không đổi DB_HOST hoặc port Docker để chạy Web từ điện thoại. Web production GitHub Pages phải dùng URL Backend HTTPS công khai; proxy Vite không tồn tại trên Pages.

## Mobile

Chép `mobile/.env.example` thành `mobile/.env`. Đặt `EXPO_PUBLIC_API_URL=http://IP-LAN-MAY-CHAY-DOCKER:3000`, hoặc `http://10.0.2.2:3000` cho Android emulator. Chạy `npm ci --prefix mobile`, `npm run mobile`. Điện thoại thật và máy tính phải cùng mạng; cho phép cổng 3000 qua Windows Firewall khi cần.

Mobile có lưu metadata, tệp video và kết quả vào cùng Backend SQL sau khi xử lý. Khách chỉ xử lý tạm. Nhận diện Whisper native cần bản development có `whisper.rn` và model; Expo Go có thể dùng lời thoại nhập tay. Web tự nhận diện trong Worker, không có ô nhập URL/lời thoại.

## Admin và SQL

Các trang đang dùng chung bộ API `/api/videos`, `/api/feedback`, `/api/admin/media` và bảng SQL phiên bản JSON. Không còn bộ API projects/uploads riêng. SQL lưu văn bản/mốc thời gian và metadata; video nằm trong volume `dubchef-uploads`. Giọng đọc TTS chạy trên thiết bị, chưa xuất file audio/video ghép giọng.

Admin có: tổng hợp, truy cập, tài khoản, video, thuyết minh, phụ đề, ngôn ngữ, phản hồi/liên hệ, đơn/giao dịch và QR. Các trang tải lại định kỳ; trình sửa tạm dừng làm mới khi có dữ liệu đang nhập. Nội dung có draft → reviewing → published, số phiên bản và lịch sử SQL.

Xóa tài khoản có dữ liệu liên kết bị từ chối để bảo toàn lịch sử; dùng khóa tài khoản. Ngôn ngữ ngoài vi/en/zh được lưu danh mục nhưng chưa cài bộ dịch mới. Các mã vi/en/zh được tắt sẽ không được gọi dịch trong lần xử lý tiếp theo; lời thoại gốc vẫn được giữ.

## Kiểm soát secret, triển khai và đóng gói

**Không đưa `.env`, `web/.env`, keystore, file SQL/dữ liệu, backup hay node_modules lên Git.**
Đọc [quy trình thu hồi/đổi khóa và dọn lịch sử Git](docs/SECURITY.md).
Đóng gói bằng `python scripts/package-share.py --check` và `python scripts/package-share.py`.
CI kiểm thử gitleaks và dừng nếu phát hiện secret. Với máy cũ, giữ nguyên `DB_PASSWORD`
đang sử dụng trong `.env`; không xóa volume SQL để cập nhật code.

## Thanh toán mô phỏng

`PAYMENT_MODE=demo` mới cho phép thanh toán mô phỏng trong môi trường thử nghiệm; mặc định `PAYMENT_MODE=disabled` trả 503, không ghi đơn paid. Không bật mô phỏng trong môi trường thu tiền thật. Chế độ demo không xác minh tiền; chế độ payOS có xác thực webhook trong backend nhưng giao dịch thật chưa được nghiệm thu trên môi trường công khai. QR `/guest` là QR trải nghiệm để đếm lượt mở trang, độc lập với thanh toán.

## Kiểm thử

```sh
npm ci --prefix server
npm ci --prefix web
npm ci --prefix mobile
npm test --prefix server
node --test shared/*.test.mjs
npm run lint
npm test --prefix web
npm test --prefix mobile -- --runInBand
npm run build --prefix web
npm run bundle --prefix mobile
```

SQL integration cần SQL Server phát triển. Test tạo database tên ngẫu nhiên riêng, không sử dụng DB_NAME thật; kiểm thử tất cả module Admin và dữ liệu sau khởi động lại, rồi chỉ xóa database tạm. Xem `docs/KIEM_THU.md`.

CI chạy Shared, Web, Mobile, toàn bộ Backend và job SQL Server riêng. CD Web đòi biến GitHub `VITE_API_URL` HTTPS cùng Pages GitHub Actions. CD Mobile đòi `EXPO_TOKEN`, biến `EXPO_PUBLIC_API_URL` và dự án EAS đã liên kết; gắn tag `mobile-v*` hoặc chạy tay và chờ build hoàn thành. Có YAML không đồng nghĩa một lần triển khai đã thành công.

## Bảo mật / ZIP chia sẻ

- Đọc `docs/BAO_MAT_VA_CHIA_SE.md` trước khi đổi mật khẩu SQL, triển khai public hoặc mở port cho thiết bị khác.
- Tạo ZIP mã nguồn không kèm `.env`/backup: `python scripts/package-share.py` (ZIP được đặt ngoài thư mục CNPM).

## Tài liệu

- `docs/Dubchef_FocusedUseCases.docx`: 23 Use Case, Activity, DFD ngữ cảnh/mức 1/mức 2, dữ liệu và kiến trúc.
- `docs/so-do/*.drawio`: nguồn sửa bằng diagrams.net; PNG/SVG để xem.
- `docs/so-do/DFD_Muc_2_MotTrang.drawio`: toàn bộ mức 2 trên một canvas.
- `docs/KIEM_THU.md`: checklist test Web Mobile Admin SQL.
- `docs/KET_QUA_KIEM_TRA.md`: kết quả kiểm tra và giới hạn xác minh.
- `db/README-QUAN-LY-SQL.md`: đường chạy SQL chuẩn và các file tùy chọn.

## Docker local (web + API + SQL Server + Ollama)

1. Máy mới: `npm run setup:local` (tạo `.env` riêng, không đưa lên Git). Máy đã có volume SQL: **giữ `.env` và mật khẩu DB cũ**, chỉ chạy `npm run setup:local` để bổ sung biến thiếu.
2. Chọn `PAYMENT_MODE=demo` trong `.env` cho bài demo **không có tiền thật**. Chọn `disabled` khi không kiểm thử; `payos` chỉ khi đã có khóa/thông tin webhook hợp lệ.
3. `docker compose up -d --build`. Web chạy ở `http://localhost:5173`, API `http://localhost:3000/api/health`, SQL Server giữ nguyên port `1433` trên loopback và volume `dubchef-data`.
4. Kiểm tra Ollama: `docker compose logs ollama-init`; chạy `bash scripts/smoke-test.sh` từ Git Bash/WSL/Linux sau khi model đã tải về.
5. Dừng bằng `docker compose down` (không thêm `-v`). Truy cập SSMS bằng `127.0.0.1,1433` hoặc `localhost,1433` tùy cấu hình máy.

`npm ci` yêu cầu Internet/registry npm hoạt động. Môi trường máy mới không tự cài Docker, không tự xoay vòng mật khẩu SQL hiện hành. CI kiểm thử độc lập; **không được diễn giải lỗi thiếu công cụ ở máy kiểm tra là PASS**.

**Nếu cập nhật mã vào repository Git cũ:** sao chép mã nguồn đã chỉnh nhưng **KHÔNG xóa `.env` cũ trên máy**. Chạy `powershell -ExecutionPolicy Bypass -File scripts/untrack-private.ps1` (Windows) hoặc `bash scripts/untrack-private.sh` (Git Bash/WSL) từ thư mục gốc để bỏ theo dõi secret; lệnh dùng `git rm --cached`, **không xóa file vật lý**. Tiếp đó kiểm tra `git status`, commit code đã kiểm tra, và thực hiện quy trình xóa lịch sử/đổi khóa trong `docs/SECURITY.md` dưới sự đồng ý của chủ repo. Nếu dùng bản ZIP mới hoàn toàn, chạy `npm run setup:local` trên máy mới để tạo secret mới.


## Trạng thái bản QA 15/11/2026 (không phải production)

- [Báo cáo QA và test thật](docs/QA_REPORT.md), [hướng dẫn điện thoại LAN/HTTPS/Expo](docs/MOBILE.md), [kiến trúc triển khai](docs/DEPLOYMENT.md).
- Đã thêm SQL pricing migration + API giá + form Admin, PWA/Expo metadata và video mẫu có nhãn rõ; **chưa nghiệm thu SQL thật, thanh toán payOS, browser/mobile thực, URL HTTPS hoặc 10/10**.
- LAN cùng Wi-Fi riêng: `npm run lan` (Windows firewall Private theo `docs/MOBILE.md`). Chỉ mở cổng web 5173, không mở 3000/1433 ra LAN.
- **Không xóa SQL volume** (`docker compose down -v`), không chép đè `.env`, không áp dụng migration vào DB đang dùng trước khi sao lưu và test với DB trắng riêng.

## Kiến trúc dịch vụ và báo cáo kiểm tra

- `services/translation`: microservice dịch phụ đề nấu ăn (từ điển ẩm thực + quy đổi đơn vị), api gọi qua REST nội bộ. Xem [docs/KIEN_TRUC_MICROSERVICES.md](docs/KIEN_TRUC_MICROSERVICES.md).
- Báo cáo kiểm tra theo yêu cầu giảng viên: [docs/BAO_CAO_KIEM_TRA_YEU_CAU_GIANG_VIEN.md](docs/BAO_CAO_KIEM_TRA_YEU_CAU_GIANG_VIEN.md).
- Test microservice: `npm test --prefix services/translation`.
