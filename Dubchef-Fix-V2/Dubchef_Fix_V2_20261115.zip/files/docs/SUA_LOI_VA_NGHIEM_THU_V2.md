# Bản sửa tiếp theo — kiến trúc và nghiệm thu

Nền áp dụng: commit `57a5fad` của `YiTang-159/CNPM`.
Không ghi đè `.env`, không đổi mật khẩu SQL, không xóa volume, không thêm dữ liệu người dùng vào Git.

## Đã sửa trong code

1. Các controller đang được `app.js` đăng ký chỉ gọi service. Nghiệp vụ payment, video, admin, cộng đồng và dịch chuyển sang các service riêng; xác thực và hạn mức tài khoản cũng qua service.
2. SQL repository chính chuyển vào `server/src/repositories/sqlRepository.js`. `server/src/db.js` chỉ giữ export tương thích. Đường dẫn seed được điều chỉnh theo vị trí mới; migration runner không thay đổi.
3. File video qua `videoStorage` repository; chống đọc đường dẫn/symlink ngoài kho upload. Ghi đường dẫn SQL chỉ khi `DuongDan IS NULL`: hai lượt upload đồng thời không được ghi đè tệp đã lưu; tệp của lượt thua được dọn.
4. Bộ đếm dịch đồng thời giảm theo số yêu cầu thực sự còn chạy, thay vì khôi phục một giá trị cũ khi request kết thúc. Có test hoàn tất yêu cầu khác thứ tự.
5. Slot xuất giọng đọc chỉ được giải phóng sau khi tải xong file, không ngay khi vừa bắt đầu gửi file.
6. Admin service tự kiểm tra role, ngoài middleware HTTP; duy trì kiểm duyệt, phiên bản và lịch sử nội dung.
7. CD Web/Services, kể cả chạy tay, chỉ triển khai/publish commit đã có CI thành công.
8. CD Mobile kiểm tra định dạng cấu hình thật, không tự điền UUID giả; EAS tiếp tục xác minh quyền truy cập project. Sau build, kiểm tra trạng thái FINISHED/ANDROID, tải APK, kiểm tra ZIP có AndroidManifest.xml và classes.dex, tính SHA-256 và đưa APK vào GitHub Artifacts. Không còn phụ thuộc trường buildDetailsPageUrl vốn có thể không có trong JSON EAS.

## Áp dụng

Giải nén bản vá V2 ra thư mục riêng. Mở PowerShell tại đó:

```powershell
powershell -ExecutionPolicy Bypass -File .\Apply-Upgrade.ps1 -RepositoryPath 'C:\Users\Ngan\Documents\GitHub\CNPM'
cd C:\Users\Ngan\Documents\GitHub\CNPM
git status --short
git add .
git commit -m 'Complete service layering and acceptance tooling'
git push origin main
```

Script kiểm tra từng file với bản nền, hỗ trợ CRLF Windows và sao lưu trước khi chép. Nếu có xung đột, dừng để đối chiếu, không ép chép đè. Bản này không thêm dependency npm; giữ nguyên cách chạy test Mobile `--runInBand` đã sửa.

## Kiểm tra máy Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\check-windows.ps1 -DataDirectory 'C:\Users\Ngan\Documents\GitHub\CNPM'
```

Nếu đã cài runner, có thể thêm `-RunnerDirectory 'C:\actions-runner'` để kiểm tra file đăng ký và tiến trình. Script chỉ kiểm tra, không tạo tài khoản, không bật cấu hình và không in giá trị `.env`.

Để CD Windows chạy thực sự, người có quyền quản trị repo cần:

- Runner Windows online, có label `dubchef`, chạy bằng tài khoản dùng được Docker Desktop.
- PowerShell 7 (`pwsh`), Node 22, Git, Docker Desktop Linux containers.
- Repo variable `DEPLOY_LOCAL_WINDOWS=true`.
- Repo variable `DUBCHEF_DEPLOY_DIR=C:\Users\Ngan\Documents\GitHub\CNPM` (hoặc thư mục thực có `.env` đang chạy).
- Environment `local-docker` đáp ứng quy tắc duyệt của nhóm nếu có.

Có thể xem runner tại https://github.com/YiTang-159/CNPM/settings/actions/runners và biến tại https://github.com/YiTang-159/CNPM/settings/variables/actions . Tài khoản không có quyền admin sẽ cần chủ repo cấu hình.

Deploy sẽ chờ container healthy rồi gọi `/api/health` và `/api/health/translation` trong API container; nếu backend hoặc model dịch chưa sẵn sàng thì báo thất bại. Chưa bật runner/biến thì job vẫn bị bỏ qua, chưa phải đã deploy.

## Nghiệm thu video thật

Cần stack Docker đã chạy và Ollama model đã tải; máy chạy script có `ffprobe` trong PATH. Tài khoản khách phải có đủ lượt upload/dịch. Script dưới đây **tải video lên server và sử dụng hạn mức thật của tài khoản**. Không chạy bằng tài khoản Admin.

Đăng nhập Web, lấy token của phiên khách của chính bạn từ ứng dụng (hoặc dùng biến ACCEPTANCE_EMAIL/ACCEPTANCE_PASSWORD trên máy riêng); không gửi token/mật khẩu vào chat hoặc Git.

```powershell
$env:ACCEPTANCE_API_URL = 'http://localhost:4000'
$env:ACCEPTANCE_TOKEN = 'TOKEN_PHIEN_KHACH_CUA_BAN'
# Nếu muốn xác minh quyền riêng tư, đặt token của một tài khoản KHÁC đang đăng nhập hợp lệ:
$env:ACCEPTANCE_OTHER_TOKEN = 'TOKEN_TAI_KHOAN_THU_HAI'
node .\scripts\acceptance-e2e.mjs 'C:\Videos\video-nau-an.mp4'
```

Có thể nhập bí mật qua hộp nhập bảo mật PowerShell thay vì ghi vào lịch sử lệnh; xóa các biến token sau khi kiểm tra. Tuyệt đối không dùng token giả từ ví dụ.

Script sẽ:

- Kiểm tra API/SQL và model dịch sẵn sàng trước khi upload.
- Upload video, tạo job `sourceLanguage=auto`, chờ trạng thái thật, báo lỗi nếu job thất bại hoặc quá 30 phút.
- Đọc lại ba bản lời thoại đã lưu và kiểm tra timestamp giống nhau giữa các ngôn ngữ.
- Tải 12 file VI/EN/ZH × MP3/MP4/SRT/VTT cùng 1 MP4 nhiều audio track; kiểm tra file không rỗng, phụ đề có timestamp, ffprobe thấy audio/video và track vie/eng/zho.
- Kiểm tra hợp đồng thuật ngữ/quy đổi/nguyên liệu/các bước.
- Nếu có tài khoản thứ hai, xác nhận tài khoản đó không đọc được video/job/file riêng.
- Ghi report.json, dung lượng và SHA-256 vào `.acceptance/<thời gian>/`. Thư mục này chứa video/file riêng nên bị loại khỏi Git và gói chia sẻ.

Report có phạm vi `video-pipeline`; không chứng minh chất lượng dịch, giọng đọc hoặc giao diện trên điện thoại. Mở/nghe video bằng Web, APK và VLC để nghiệm thu những phần đó. Chạy lần lượt video gốc Việt/Anh/Trung, kiểm tra nguyên liệu, số lượng, đơn vị và thời gian hiển thị.

## Build APK thật

Người quản trị repo đặt secret `EXPO_TOKEN` và variables `EXPO_OWNER`, `EXPO_PROJECT_ID`, `EXPO_PUBLIC_API_URL` của nhóm. URL backend phải HTTPS và điện thoại truy cập được.

Chạy Actions → CD Mobile → Run workflow. Khi build thành công, tải **dubchef-android-apk** ở mục Artifacts và cài lên điện thoại. Không coi bundle JavaScript là APK hoặc coi việc có workflow là đã nghiệm thu Mobile CD.

## Kết quả kiểm tra bản V2 tại đây

- Node **22.23.5**: **97/97 test backend không gồm hai bộ SQL**, không bỏ qua test media; có FFmpeg/eSpeak xuất file thật.
- Node 22, cache Jest sạch, chạy tuần tự: **17/17 test Mobile**.
- Shared/source/configuration/acceptance contracts: **36/36**.
- Python STT HTTP contracts: **2/2**; cấu hình Compose và workflow YAML đọc được.
- Test kiến trúc chặn controller dùng repository/SQL trực tiếp; test quyền Admin, upload đồng thời và bộ đếm dịch đều qua.
- Phần Web không đổi UI trong V2; chưa chạy lại build Web tại môi trường này. CI sau khi áp dụng sẽ kiểm tra.
- Hai bộ SQL đã qua CI ở bản nền `57a5fad`, nhưng chưa chạy lại trên mã V2 tại đây; cần CI xác nhận lại đường dẫn repository/seed và ghi upload có điều kiện.
- Script acceptance mới được kiểm tra hợp đồng bằng fixture HTTP. Chưa chạy nó với backend Windows của bạn, chưa cài APK và chưa kích hoạt runner/Expo của nhóm.

Đây là bản sửa code và công cụ kiểm chứng; chỉ đánh dấu đồ án nghiệm thu đầy đủ khi các bước chạy thật trên máy nhóm đã có kết quả.
