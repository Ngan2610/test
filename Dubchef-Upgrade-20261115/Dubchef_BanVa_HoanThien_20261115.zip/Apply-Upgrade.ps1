param([Parameter(Mandatory=$true)][string]$RepositoryPath)
$ErrorActionPreference = 'Stop'
$repository = (Resolve-Path $RepositoryPath).Path
if (-not (Test-Path (Join-Path $repository 'package.json'))) { throw 'RepositoryPath must point to the CNPM project root.' }
function Get-CanonicalHash([string]$Path) {
  $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
  if ($null -eq $text) { $text = '' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($text.Replace("`r`n", "`n"))
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant() }
  finally { $sha.Dispose() }
}
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$conflicts = @()
foreach ($entry in $manifest.files) {
  $target = Join-Path $repository $entry.path
  if (Test-Path -LiteralPath $target) {
    $hash = Get-CanonicalHash $target
    if ($hash -ne $entry.normalizedSha256 -and $hash -ne $entry.previousNormalizedSha256) { $conflicts += $entry.path }
  } elseif ($entry.previousSha256) { $conflicts += $entry.path }
}
if ($conflicts.Count) {
  Write-Output 'These files differ from the original and upgraded versions. No files were changed:'
  $conflicts | ForEach-Object { Write-Output " - $_" }
  throw 'Resolve the listed source conflicts before applying the upgrade.'
}
$backup = Join-Path $repository ('.upgrade-backups/' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$changed = 0
foreach ($entry in $manifest.files) {
  $source = Join-Path (Join-Path $PSScriptRoot 'files') $entry.path
  if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Archive integrity mismatch: $($entry.path)" }
}
foreach ($entry in $manifest.files) {
  $source = Join-Path (Join-Path $PSScriptRoot 'files') $entry.path
  $target = Join-Path $repository $entry.path
  if (Test-Path -LiteralPath $target) {
    if ((Get-CanonicalHash $target) -eq $entry.normalizedSha256) { continue }
    $saved = Join-Path $backup $entry.path
    New-Item -ItemType Directory -Force -Path (Split-Path $saved -Parent) | Out-Null
    Copy-Item -LiteralPath $target -Destination $saved
  }
  New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
  Copy-Item -LiteralPath $source -Destination $target
  $changed++
}
Write-Output "Applied $changed files. Existing .env and Docker volumes were not changed."
Write-Output "Source backups: $backup"
Write-Output 'Next: npm ci --prefix server; npm ci --prefix web; npm ci --prefix mobile'
Write-Output 'Read docs/HOAN_THIEN_VA_CAI_DAT_WINDOWS.md before starting Docker or enabling deployment.'
