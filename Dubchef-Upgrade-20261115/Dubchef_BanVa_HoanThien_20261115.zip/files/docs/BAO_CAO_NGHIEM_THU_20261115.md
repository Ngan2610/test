# Kết quả kiểm tra bản hoàn thiện Dubchef

Ngày: 15/11/2026. Nền mã nguồn: `6ec1b51`, repo `YiTang-159/CNPM`.
Môi trường kiểm tra bản nâng cấp: Node 24.22.1 trên Linux, Python 3.12, FFmpeg, eSpeak-ng 1.52 cài trong thư mục kiểm thử. CI dự án vẫn dùng Node 22. Không coi hai môi trường là hoàn toàn tương đương.

## Đã chạy và có kết quả

| Hạng mục | Kết quả |
|---|---|
| Web lint | Không lỗi/cảnh báo ở lần chạy cuối |
| Web test | 124/124, 19 file test |
| Web build | Thành công |
| Mobile lint | Không lỗi/cảnh báo |
| Mobile test | 17/17, 3 bộ test; có test tải phụ đề với token và chia sẻ file |
| Mobile Android JS bundle | Thành công; 851 module, khoảng 2,36 MB. Đây không phải APK đã cài trên điện thoại |
| Shared + source contracts | 30/30 |
| Backend không gồm 2 bộ SQL | 93/93, không skip; có test xuất file media thật và MP4 đa track |
| Render HTTP service | 3/3 |
| Translation service | 26/26 |
| Transcription HTTP | 2/2: token, đường dẫn, symlink, ngôn ngữ, giao thức inference |
| Whisper model thật | `tiny` CPU int8: tự nhận tiếng Anh với xác suất 0,877; trả 1 câu có timestamp 0–6,48 giây từ video tạo để thử |
| STT → render thật | Nhận diện thật, xuất MP3/MP4/SRT/VTT thật; repository test trong bộ nhớ; chưa gọi Ollama thật trong lần kiểm tra này. Chi tiết trong `evidence/upgrade/real-pipeline.json` |
| MP4 nhiều audio track | FFmpeg/ffprobe xác nhận 1 video track + 2 audio tracks nhãn vie/eng |
| Docker Compose | `docker compose config --quiet` qua với mật khẩu fixture; không in cấu hình bí mật |
| Workflow YAML | 4 file đọc/parse được; chưa phải bằng chứng workflow mới chạy thành công trên GitHub |
| npm audit Mobile | 0 high/critical; vẫn còn 10 low + 24 moderate trong cây dependency Expo/RN cũ |
| Kiểm tra gói chia sẻ | Script privacy qua; ZIP không chứa `.env`, backup, node_modules, Git metadata, file upload riêng |

Whisper tiny chép thiếu từ đầu của câu thử ("Add" thành "and"); vì vậy không khẳng định chất lượng nhận diện đã đạt cho tiếng Việt/Trung hay tiếng ồn bếp. Mặc định bản chạy dùng `small` và cần nghiệm thu bằng video nhóm.

## Chưa thể nghiệm thu trong môi trường này

1. **Hai bộ SQL:** `sql.integration.test.mjs`, `integrity.integration.test.mjs`. Đã thử dựng SQL Server 2022 nhưng rootless Docker dùng VFS làm đầy giới hạn đĩa khi tạo container; đã xóa riêng image/container thử nghiệm. Không sửa test thành skip, không hạ coverage threshold 80%. Khi chạy toàn bộ suite thiếu SQL, 2 bộ này báo lỗi và coverage chỉ 70,09% (đặc biệt các nhánh entitlements phụ thuộc SQL).
2. **Toàn bộ Docker + Ollama:** chưa thực hiện luồng nhiều ngôn ngữ với model dịch thật. Các test translation HTTP/worker có dùng bộ dịch kiểm thử. Chưa đo chất lượng dịch VI/EN/ZH.
3. **Build lại toàn bộ Docker image:** cấu hình đã kiểm tra; cần CI chạy image mới, nhất là transcription Python. Không đánh dấu Docker build mới đã qua dựa vào lần CI trước.
4. **Điện thoại/APK:** cần Expo account/project/token, backend HTTPS, build EAS và cài trên thiết bị thật. Bundle JS thành công không chứng minh native build thành công.
5. **CD Services lên Windows:** workflow và script đã thêm; phải thiết lập runner Windows label `dubchef`, biến deployment và Docker Desktop theo hướng dẫn. Chưa được phép báo đã triển khai trên máy người dùng.
6. **Secrets cũ:** không đổi mật khẩu SQL/token hay viết lại lịch sử Git. Nếu có khóa từng lộ, quản trị viên phải thay ở dịch vụ thật.

## Đối chiếu yêu cầu giảng viên

- React.js + React Native: đã có code giao diện và kiểm thử cả hai nền tảng.
- Backend theo 3 lớp: đã tách các controller khỏi composition root; nghiệp vụ tài khoản và xử lý video đặt ở services; dữ liệu SQL qua repository và các module truy cập dữ liệu hiện có. Các policy giá/hạn mức/thanh toán tiếp tục giữ phía server.
- Các service giao tiếp: có hợp đồng HTTP thực thi cho STT, translation, render; có token, kiểm soát đường dẫn và test. Ollama là inference backend của translation.
- CI/CD: đã có workflow cho FE, API và các service, Mobile APK. Chỉ xác nhận hoàn tất nghiệm thu khi những workflow tương ứng thực sự chạy thành công với cấu hình của nhóm.

## Checklist ký nghiệm thu trên máy nhóm

- [ ] Push bản nâng cấp và CI xanh toàn bộ, gồm SQL + coverage + Docker/STT image.
- [ ] Docker Desktop đủ dung lượng; migrate thành công; các service healthy; Ollama model đã tải.
- [ ] Video Việt, Anh, Trung thật: nhận đúng tiếng, kiểm tra timestamp, thuật ngữ, đơn vị và nội dung bản dịch.
- [ ] Tải/phát được MP3/MP4/SRT/VTT; VLC thấy đủ track của MP4 multi.
- [ ] Web và điện thoại cùng dùng API thật, mở lại video và tiến độ sau khi đóng ứng dụng.
- [ ] Thử tài khoản khác, tài khoản bị khóa, quota hết và retry; không đọc chéo dữ liệu hoặc trừ lặp hạn mức.
- [ ] CD Services cập nhật Docker Desktop, dữ liệu và `.env` cũ còn nguyên.
- [ ] CD Mobile tạo APK, cài và thử chia sẻ/phát file trên điện thoại.
- [ ] Người quản trị rà soát khóa, mật khẩu cũ và backup SQL.
