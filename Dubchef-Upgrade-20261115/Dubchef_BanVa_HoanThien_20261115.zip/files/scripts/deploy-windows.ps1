param([Parameter(Mandatory=$true)][string]$DataDirectory)
$ErrorActionPreference = 'Stop'
$sourceRoot = Split-Path $PSScriptRoot -Parent
$envFile = Join-Path $DataDirectory '.env'
if (-not (Test-Path $envFile)) { throw "Missing $envFile; preserve your existing SQL password and configure this file first." }
if (-not $env:DUBCHEF_RELEASE -or -not $env:DUBCHEF_IMAGE_PREFIX) { throw 'Set DUBCHEF_RELEASE and DUBCHEF_IMAGE_PREFIX' }
$compose = @('compose', '--project-directory', $DataDirectory, '--env-file', $envFile,
  '-f', (Join-Path $sourceRoot 'docker-compose.yml'), '-f', (Join-Path $sourceRoot 'docker-compose.release.yml'))
& docker @compose config --quiet
if ($LASTEXITCODE -ne 0) { throw 'Invalid Compose configuration' }
& docker @compose pull api migrate job-worker web translation render transcription
if ($LASTEXITCODE -ne 0) { throw 'Image pull failed; running containers were not updated' }
& docker @compose up -d --no-build --wait --wait-timeout 1200
if ($LASTEXITCODE -ne 0) { throw 'Deployment is not healthy; inspect docker compose logs. Existing data was retained.' }
& docker @compose ps
Write-Output "Deployed commit $env:DUBCHEF_RELEASE. Web: http://localhost:5173; API: http://localhost:4000/api/health"
