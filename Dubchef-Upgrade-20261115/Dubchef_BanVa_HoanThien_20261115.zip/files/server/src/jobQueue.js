// Compatibility export: active queue is SQL-backed; no Redis/BullMQ dependency.
export { runVideoWorker, processVideoJob } from './services/jobWorker.js';
