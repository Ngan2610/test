// HTTP controllers are registered by the composition root.
export { registerVideoRoutes } from './routes/videoRoutes.js';
