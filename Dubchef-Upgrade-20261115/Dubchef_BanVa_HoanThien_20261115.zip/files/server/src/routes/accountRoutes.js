import {createAccountService} from '../services/accountService.js';
import {makeToken} from '../auth.js';
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res)).catch(next);
const publicUser=(u,secret)=>({id:u.id,name:u.name,email:u.email,role:u.role,token:makeToken(u,secret)});
export function registerAccountRoutes(app,{repo,secret,throttle,auth,customerOnly}) {
  const service=createAccountService(repo,secret);
  app.post('/api/auth/register',throttle('register',20,15*60*1000),wrap(async(req,res)=>{
    res.status(201).json({user:await service.register(req.body)});
  }));
  app.post('/api/auth/login',throttle('login',60,15*60*1000),wrap(async(req,res)=>{
    res.json({user:await service.login(req.body,req.ip)});
  }));
  app.get('/api/me',auth,(req,res)=>res.json({user:publicUser(req.currentUser,secret)}));
  app.get('/api/me/entitlements',customerOnly,wrap(async(req,res)=>{
    res.set('Cache-Control','no-store');res.json(await repo.entitlements(req.currentUser.id));
  }));
  app.patch('/api/me',auth,wrap(async(req,res)=>{
    res.json({user:await service.updateProfile(req.currentUser,req.body)});
  }));
  app.patch('/api/me/password',auth,wrap(async(req,res)=>{
    await service.changePassword(req.currentUser,req.body);res.json({ok:true});
  }));
}
