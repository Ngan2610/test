// Các đường dẫn API. `repo` là lớp truy cập CSDL (db.js), tách ra để dễ thay khi kiểm thử.
import { unlink } from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import { buildStats } from '../stats.js';
import { validMediaLines, validateFeedback, MEDIA_STATES } from '../adminPolicy.js';
import { validateLegacyOwnerLink } from '../legacyOrders.js';

const VALID_LANG = /^[a-z]{2,8}$/;
const PROCESSING_LANGUAGES = new Set(['vi','en','zh']);
const STATUS = ['uploaded','processing','completed','failed','hidden'];
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);


export function registerAdminRoutes(app, { repo, tz, UPLOAD_DIR, adminOnly, videoFor }) {
  // ---- Trang quản trị ----
  app.get('/api/admin/overview', adminOnly, wrap(async (req, res) => {
    const span = [7, 14, 30].includes(Number(req.query.days)) ? Number(req.query.days) : 7;
    const raw = await repo.visitStats(span, tz);
    res.json({ stats: buildStats(raw, Date.now(), span, tz) });
  }));

  // Số người quét mã QR của khách: cùng dạng với /overview (visitors = người quét, views = lượt quét)
  app.get('/api/admin/qr', adminOnly, wrap(async (req, res) => {
    const span = [7, 14, 30].includes(Number(req.query.days)) ? Number(req.query.days) : 7;
    const raw = await repo.qrStats(span, tz);
    res.json({ stats: buildStats(raw, Date.now(), span, tz) });
  }));

  app.get('/api/admin/users', adminOnly, wrap(async (req, res) => {
    const users = (await repo.listUsers()).filter((u) => u.role === 'user');
    res.json({ users: users.map(({ name, email, at, status }) => ({ name, email, at, status })) });
  }));

  // Trang tổng hợp: nhiều module, một API duy nhất; luôn xác thực quyền Admin.
  app.get('/api/admin/dashboard', adminOnly, wrap(async (req, res) => {
    res.json(await repo.dashboardSummary());
  }));

  // API thống kê tổng quan Admin từ SQL Server
  app.get('/api/admin/statistics', adminOnly, wrap(async (req, res) => {
    const statistics = await repo.adminStatistics();

    res.json({
      success: true,
      statistics
    });
  }));

  app.get('/api/admin/videos', adminOnly, wrap(async (req, res) => {
    const videos = await repo.listVideos();
    res.json({
      videos
    });
  }));

  // Quản lý nội dung theo quy trình kiểm duyệt; có phiên bản và audit SQL.
  const mediaKind = value => ['narrations', 'subtitles'].includes(value);
  const mediaId = value => Number.isSafeInteger(Number(value)) && Number(value) > 0;
  const mediaLanguage = value => VALID_LANG.test(value || '');

  app.get('/api/admin/media/:kind', adminOnly, wrap(async (req, res) => {
    if (!mediaKind(req.params.kind)) return res.status(400).json({code:'invalid'});
    res.json({ items: await repo.mediaIndex(req.params.kind) });
  }));
  app.get('/api/admin/media/:kind/:id/:language/history', adminOnly, wrap(async (req, res) => {
    if (!mediaKind(req.params.kind) || !mediaId(req.params.id) || !mediaLanguage(req.params.language))
      return res.status(400).json({code:'invalid'});
    res.json({history: await repo.mediaHistory(req.params.kind, Number(req.params.id), req.params.language)});
  }));
  app.get('/api/admin/media/:kind/:id/:language', adminOnly, wrap(async (req, res) => {
    if (!mediaKind(req.params.kind) || !mediaId(req.params.id) || !mediaLanguage(req.params.language))
      return res.status(400).json({code:'invalid'});
    const item = await repo.mediaDetail(req.params.kind, Number(req.params.id), req.params.language);
    if (!item) return res.status(404).json({code:'not_found'});
    res.json({ item });
  }));
  app.put('/api/admin/media/:kind/:id/:language', adminOnly, wrap(async (req, res) => {
    const {kind,id,language} = req.params;
    const {lines,status,version} = req.body || {};
    if (!mediaKind(kind) || !mediaId(id) || !mediaLanguage(language) ||
        !MEDIA_STATES.includes(status) ||
        !Number.isSafeInteger(version) || version < 0 || !validMediaLines(lines))
      return res.status(400).json({code:'invalid'});
    const video = await repo.getVideo(Number(id));
    if (!video) return res.status(404).json({code:'not_found'});
    try {
      const result = await repo.saveManagedMedia({kind,videoId:Number(id),language,
        lines,status,version,editor:req.currentUser.email});
      res.json({ok:true, ...result});
    } catch (e) {
      if (e.code === 'conflict' || e.code === 'review_required' || e.code === 'reopen_required')
        return res.status(409).json({code:e.code});
      throw e;
    }
  }));
  app.get('/api/admin/languages', adminOnly, wrap(async (req, res) => res.json({ languages: (await repo.languages()).map(x => ({ ...x, processingSupported: PROCESSING_LANGUAGES.has(x.code) })) })));
  app.post('/api/admin/languages', adminOnly, wrap(async (req, res) => {
    const code = String(req.body?.code || '').toLowerCase().trim();
    const name = String(req.body?.name || '').trim();
    const englishName = String(req.body?.englishName || '').trim();
    if (!VALID_LANG.test(code) || !name || name.length > 80 || !englishName || englishName.length > 80)
      return res.status(400).json({ code: 'invalid' });
    if (!await repo.createLanguage({ code, name, englishName, status: PROCESSING_LANGUAGES.has(code) ? 'active' : 'inactive' })) return res.status(409).json({ code: 'exists' });
    res.status(201).json({ ok: true });
  }));
  app.patch('/api/admin/languages/:code', adminOnly, wrap(async (req, res) => {
    const code = String(req.params.code || '');
    const name = String(req.body?.name || '').trim();
    const englishName = String(req.body?.englishName || '').trim();
    const status = req.body?.status;
    if (!VALID_LANG.test(code) || !name || name.length > 80 || !englishName || englishName.length > 80 || !['active','inactive'].includes(status))
      return res.status(400).json({ code: 'invalid' });
    if (status === 'active' && !PROCESSING_LANGUAGES.has(code)) return res.status(409).json({code:'language_not_supported'});
    if (!await repo.updateLanguage(code, { name, englishName, status })) return res.status(404).json({ code: 'not_found' });
    res.json({ ok: true });
  }));
  app.patch('/api/admin/videos/:id/results/:kind/:language', adminOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res, true);
    if (!video) return;
    const { kind, language } = req.params;
    if (!['narrations','subtitles'].includes(kind) || !VALID_LANG.test(language))
      return res.status(400).json({ code: 'invalid' });
    const lines = req.body?.lines;
    if (!Array.isArray(lines) || !lines.length || lines.length > 2000 ||
        lines.some(x => !x || typeof x.text !== 'string' || x.text.length > 4000 ||
          (x.start != null && (!Number.isFinite(x.start) || x.start < 0)) ||
          (x.end != null && (!Number.isFinite(x.end) || x.end < 0))))
      return res.status(400).json({ code: 'invalid' });
    // API cũ chuyển về cơ chế quản trị có lịch sử, không cho cập nhật âm thầm ngoài kiểm duyệt.
    return res.status(410).json({ code: 'use_media_management' });
  }));
  app.get('/api/admin/videos/:id/translations', adminOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res, true);
    if (!video) return;
    res.json(await repo.videoResults(video.id));
  }));
  app.patch('/api/admin/videos/:id', adminOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res, true);
    if (!video) return;
    const status = String(req.body?.status || '');
    if (!STATUS.includes(status)) return res.status(400).json({ code: 'invalid' });
    await repo.setVideoStatus(video.id, status, req.currentUser.email);
    res.json({ ok: true });
  }));
  app.delete('/api/admin/videos/:id', adminOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res, true);
    if (!video) return;
    await repo.deleteVideo(video.id);
    if (video.videoUrl && video.videoUrl.startsWith(UPLOAD_DIR + sep)) await unlink(video.videoUrl).catch(() => {});
    res.json({ ok: true });
  }));
  app.get('/api/admin/feedback', adminOnly, wrap(async (req, res) => {
    res.json({ feedback: await repo.allFeedback() });
  }));
  app.get('/api/admin/feedback/:id/history', adminOnly, wrap(async (req, res) => {
    if (!/^[fc]-[1-9]\d*$/.test(req.params.id)) return res.status(400).json({code:'invalid'});
    res.json({history: await repo.feedbackHistory(req.params.id)});
  }));
  app.patch('/api/admin/feedback/:id', adminOnly, wrap(async (req, res) => {
    const id = req.params.id;
    const status = String(req.body?.status || '');
    const reply = String(req.body?.reply || '').trim();
    const priority = String(req.body?.priority || 'normal');
    if (!/^[fc]-[1-9]\d*$/.test(id) || !validateFeedback({status, priority, reply}))
      return res.status(400).json({ code: 'invalid' });
    if (!await repo.handleFeedback(id, {status,reply:reply||null,priority,editor:req.currentUser.email}))
      return res.status(404).json({ code: 'not_found' });
    res.json({ ok: true });
  }));
  app.get('/api/admin/entitlements', adminOnly, wrap(async(req,res)=>{
    const email=String(req.query.email || '').trim().toLowerCase();
    if (!EMAIL.test(email)) return res.status(400).json({code:'invalid'});
    const data=await repo.entitlementsForEmail(email);
    if (!data) return res.status(404).json({code:'not_found'});
    res.set('Cache-Control','no-store');
    res.json(data);
  }));
  app.get('/api/admin/orders', adminOnly, wrap(async (req, res) => {
    res.json({ orders: await repo.adminOrders() });
  }));

  // Đơn cũ không được tự gán qua email. Chỉ Admin đã xác thực mới được
  // đề xuất/ghi nhận người sở hữu kèm chứng từ độc lập và nhật ký kiểm toán.
  const legacyOrderId = value => {
    if (!/^[1-9]\d*$/.test(value)) return null;
    const id = Number(value);
    return Number.isSafeInteger(id) && id <= 2147483647 ? id : null;
  };
  const legacyError = (res, err) => {
    if (err?.code === 'not_found') return res.status(404).json({ code: 'not_found' });
    if (['already_linked', 'ambiguous_owner', 'email_mismatch'].includes(err?.code))
      return res.status(409).json({ code: err.code });
    if (err?.code === 'invalid') return res.status(400).json({ code: 'invalid' });
    throw err;
  };
  app.get('/api/admin/orders/:id/owner-candidates', adminOnly, wrap(async (req, res) => {
    const id = legacyOrderId(req.params.id);
    if (!id) return res.status(400).json({ code: 'invalid' });
    const result = await repo.legacyOwnerCandidates(id);
    if (!result) return res.status(404).json({ code: 'not_found' });
    res.set('Cache-Control', 'no-store');
    res.json(result);
  }));
  app.post('/api/admin/orders/:id/link-owner', adminOnly, wrap(async (req, res) => {
    const id = legacyOrderId(req.params.id);
    if (!id || !validateLegacyOwnerLink(req.body)) return res.status(400).json({ code: 'invalid' });
    try {
      const result = await repo.linkLegacyOwner(id, req.body, req.currentUser.email);
      res.set('Cache-Control', 'no-store');
      res.json(result);
    } catch (err) { return legacyError(res, err); }
  }));
  app.get('/api/admin/audit', adminOnly, wrap(async (req, res) => {
    const count = Math.min(200, Math.max(1, Number.parseInt(req.query.limit, 10) || 50));
    res.json({ activities: await repo.adminAudit(count) });
  }));

  app.patch('/api/admin/users', adminOnly, wrap(async (req, res) => {
    const email = String((req.body && req.body.email) || '').trim().toLowerCase();
    const status = req.body && req.body.status;
    if (!['active', 'locked'].includes(status)) return res.status(400).json({ code: 'invalid' });
    if (!(await repo.setUserStatus(email, status, req.currentUser.email))) return res.status(404).json({ code: 'not_found' });
    res.json({ ok: true });
  }));

  app.post('/api/admin/users/anonymize', adminOnly, wrap(async(req,res)=>{
    const email=String(req.body?.email||'').trim().toLowerCase();
    if (!EMAIL.test(email) || req.body?.confirmed!==true)
      return res.status(400).json({code:'confirmation_required'});
    const ok=await repo.anonymizeUser(email,req.currentUser.email);
    return ok ? res.json({ok:true}) : res.status(404).json({code:'not_found'});
  }));

  app.delete('/api/admin/users', adminOnly, wrap(async (req, res) => {
    const email = String(req.query.email || '').trim().toLowerCase();
    try {
      if (!(await repo.deleteUser(email, req.currentUser.email))) return res.status(404).json({ code: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      if (err.number === 547) return res.status(409).json({ code: 'has_data' });
      throw err;
    }
  }));

}
