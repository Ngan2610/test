// Các đường dẫn API. `repo` là lớp truy cập CSDL (db.js), tách ra để dễ thay khi kiểm thử.
import { resolve } from 'node:path';

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);


export function registerCommunityRoutes(app, { repo, auth }) {
  // ---- Phản hồi có tài khoản ----
  app.get('/api/feedback', auth, wrap(async (req, res) => {
    res.json({ feedback: await repo.userFeedback(req.currentUser.email) });
  }));
  app.post('/api/feedback', auth, wrap(async (req, res) => {
    const message = String(req.body?.message || '').trim();
    const videoId = req.body?.videoId == null || req.body?.videoId === '' ? null : Number(req.body.videoId);
    if (!message || message.length > 2000 || (videoId !== null && (!Number.isSafeInteger(videoId) || videoId <= 0)))
      return res.status(400).json({ code: 'invalid' });
    if (videoId !== null) {
      const video = await repo.getVideo(videoId);
      if (!video || video.userEmail !== req.currentUser.email) return res.status(404).json({ code: 'not_found' });
    }
    const feedback = await repo.addFeedback(req.currentUser.email, message, videoId);
    res.status(201).json({ feedback });
  }));

  app.post('/api/contact', wrap(async (req, res) => {
    const b = req.body || {};
    const name = String(b.name || '').trim();
    const email = String(b.email || '').trim().toLowerCase();
    const body = String(b.message || '').trim();
    if (!name || name.length > 100 || !EMAIL.test(email) || !body || body.length > 2000) return res.status(400).json({ code: 'invalid' });
    await repo.addMessage({ name, email, body });
    res.status(201).json({ ok: true });
  }));

  // ---- Đếm truy cập ----
  app.post('/api/track', wrap(async (req, res) => {
    const b = req.body || {};
    const visitorId = String(b.visitorId || '');
    const path = String(b.path || '');
    const lang = String(b.lang || '');
    if (!/^[\w-]{1,64}$/.test(visitorId) || !path.startsWith('/') || path.length > 200 || !/^[a-z]{2,8}$/.test(lang)) {
      return res.status(400).json({ code: 'invalid' });
    }
    if (path.startsWith('/admin')) return res.status(204).end();
    await repo.addVisit({ visitorId, path, lang });
    res.status(204).end();
  }));

  // ---- Đếm lượt quét mã QR của khách (trang /guest) ----
  app.post('/api/qr-scan', wrap(async (req, res) => {
    const b = req.body || {};
    const visitorId = String(b.visitorId || '');
    const lang = String(b.lang || '');
    if (!/^[\w-]{1,64}$/.test(visitorId) || !/^[a-z]{2,8}$/.test(lang)) return res.status(400).json({ code: 'invalid' });
    await repo.addQrScan({ visitorId, lang });
    res.status(204).end();
  }));

}
