// Compatibility export. Job endpoints live alongside video authorization.
export { registerVideoRoutes } from './videoRoutes.js';
