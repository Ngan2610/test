// Các đường dẫn API. `repo` là lớp truy cập CSDL (db.js), tách ra để dễ thay khi kiểm thử.
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { METHODS, newTransactionRef, validateOrder } from '../orders.js';
import { cleanPriceUpdate } from '../pricingPolicy.js';

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);


export function registerPaymentRoutes(app, { repo, paymentMode, gateway, throttle, adminOnly, customerOnly }) {
  // Database is the single source for price and limits; public GET cannot leak account info.
  app.get('/api/pricing', wrap(async (_req,res) => {
    if (!repo.getPricing) return res.status(503).json({code:'pricing_unavailable'});
    res.json(await repo.getPricing());
  }));
  app.get('/api/admin/pricing/history', adminOnly, wrap(async (_req,res) => {
    res.json({ history:await repo.getPricingHistory() });
  }));
  app.put('/api/admin/pricing', adminOnly, wrap(async(req,res) => {
    const checked=cleanPriceUpdate(req.body);
    if(checked.error) return res.status(400).json({code:checked.error});
    try { res.json({pricing:await repo.updatePricing(checked.value,req.currentUser.email)}); }
    catch(e) { if(e.code==='price_changed') return res.status(409).json({code:e.code}); throw e; }
  }));

  // Tạo đơn: giá do máy chủ tính, trạng thái "pending"
  app.post('/api/orders', throttle('orders', 30, 60 * 1000), customerOnly, wrap(async (req, res) => {
    const policy = repo.getPricing ? await repo.getPricing() : null;
    if (repo.getPricing && (!Number.isSafeInteger(req.body?.priceVersion) || req.body.priceVersion < 1))
      return res.status(409).json({code:'price_changed'});
    const selectedCurrency = ['VND','USD','CNY'][Number(req.body?.L)];
    const configured = policy?.currencies?.find(p => p.currency === selectedCurrency);
    const v = validateOrder(req.body, configured || undefined);
    if (v.error) return res.status(400).json({ code: v.error });
    if (v.value.email !== req.currentUser.email) return res.status(403).json({ code: 'forbidden' });
    if (paymentMode === 'payos' && v.value.L !== 0) return res.status(422).json({code:'currency_unsupported'});
    // Chủ sở hữu lấy từ token đã đối chiếu SQL, tuyệt đối không lấy MaNguoiDung từ form.
    let order;
    try { order = await repo.createOrder({ ...v.value, currency:selectedCurrency,
      priceVersion:req.body?.priceVersion, userId:req.currentUser.id, name:req.currentUser.name }); }
    catch(e) { if(['price_changed','invalid_quantity'].includes(e.code)) return res.status(409).json({code:e.code}); throw e; }
    if (!order) return res.status(409).json({ code: 'account_unavailable' });
    res.status(201).json({ order });
  }));

  // Công khai chế độ (không bao gồm bí mật của nhà cung cấp).
  app.get('/api/payments/config', (req, res) => {
    const mode = paymentMode === 'payos' && !gateway ? 'unavailable' : paymentMode;
    res.json({ mode, methods: mode === 'payos' ? ['qr', 'bank'] : mode === 'demo' ? METHODS : [],
      supportedCurrencies: mode === 'payos' ? ['VND'] : mode === 'demo' ? ['VND','USD','CNY'] : [] });
  });

  // Trạng thái thanh toán lấy từ SQL, chỉ chủ đơn được xem. Không chấp nhận trạng thái từ URL trở về.
  app.get('/api/orders/:id/status', customerOnly, wrap(async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({code:'invalid'});
    const order = await repo.getOrderForPayment(id, req.currentUser.id);
    if (!order) return res.status(404).json({code:'not_found'});
    res.json({ order });
  }));

  // Link payOS được tạo bởi máy chủ từ số tiền đã lưu trong SQL. Không được tự gắn 'paid'.
  app.post('/api/orders/:id/checkout', throttle('checkout', 30, 60 * 1000), customerOnly, wrap(async (req, res) => {
    if (paymentMode !== 'payos' || !gateway) return res.status(503).json({code:'payment_unavailable'});
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({code:'invalid'});
    const order = await repo.getOrderForPayment(id, req.currentUser.id);
    if (!order) return res.status(404).json({code:'not_found'});
    if (order.status !== 'pending') return res.status(409).json({code:'not_payable'});
    if (order.currency !== 'VND' || !Number.isSafeInteger(order.amountMinor) || order.amountMinor <= 0)
      return res.status(422).json({code:'currency_unsupported'});
    try {
      const link = await gateway.createCheckout(order);
      res.json({ order, ...link });
    } catch (err) {
      console.error('payOS checkout:', err.message);
      res.status(502).json({code:'payment_gateway_unavailable'});
    }
  }));

  // Webhook payOS phải có chữ ký HMAC hợp lệ. Browser returnUrl KHÔNG xác nhận thanh toán.
  app.post('/api/payments/payos/webhook', throttle('payos-webhook', 240, 60 * 1000), wrap(async (req, res) => {
    if (paymentMode !== 'payos' || !gateway) return res.status(503).json({code:'payment_unavailable'});
    let event;
    try { event = gateway.verifyWebhook(req.body); }
    catch { return res.status(400).json({code:'invalid_signature'}); }
    if (!event.success) return res.json({ok:true,ignored:true});
    const id = event.orderCode;
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({code:'invalid'});
    const order = await repo.getOrderForPayment(id); // callback độc lập tài khoản khách
    if (!order) return res.json({ok:true,ignored:true}); // webhook kiểm tra cấu hình của payOS
    if (order.currency !== 'VND' || event.currency !== 'VND' || event.amount !== order.amountMinor)
      return res.status(409).json({code:'payment_mismatch'});
    if (!/^[A-Za-z0-9_-]{4,40}$/.test(event.reference))
      return res.status(400).json({code:'invalid_reference'});
    if (order.status === 'paid') return res.json({ok:true,alreadyProcessed:true});
    if (order.status !== 'pending') return res.status(409).json({code:'not_payable'});
    const payloadSha256 = createHash('sha256').update(JSON.stringify(req.body)).digest('hex');
    const payment={method:'qr',ref:event.reference,source:'payos'};
    const result = typeof repo.payVerifiedWebhook==='function'
      ? await repo.payVerifiedWebhook(id,{...payment,verifiedWebhook:{eventId:`payos:${event.reference}`,payloadSha256}})
      : await repo.payOrder(id,payment); // SQL-less test repositories implement the legacy interface.
    if (!result) return res.json({ok:true,alreadyProcessed:true}); // cuộc đua callback trùng
    res.json({ok:true,paid:true});
  }));

  // Thanh toán mô phỏng: CHỈ hoạt động khi chủ dự án chủ động bật PAYMENT_MODE=demo.
  // Thanh toán giả lập: không nhận số thẻ, chỉ ghi phương thức và mã giao dịch
  app.post('/api/orders/:id/pay', throttle('demo-pay', 30, 60 * 1000), customerOnly, wrap(async (req, res) => {
    const id = Number(req.params.id);
    const method = req.body && req.body.method;
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ code: 'invalid' });
    if (!METHODS.includes(method)) return res.status(400).json({ code: 'method' });
    if (!await repo.orderOwner(id, req.currentUser.id)) return res.status(404).json({ code: 'not_found' });
    if (paymentMode !== 'demo') return res.status(503).json({ code: 'payment_unavailable' });
    const result = await repo.payOrder(id, { method, ref: newTransactionRef(method) });
    if (!result) return res.status(409).json({ code: 'not_payable' });
    res.json(result);
  }));

  // Đơn hàng chỉ được xem bởi chính tài khoản đã tạo.
  app.get('/api/orders', customerOnly, wrap(async (req, res) => {
    res.json({ orders: await repo.listOrders(req.currentUser.email, 20, req.currentUser.id) });
  }));

}
