import { cookingInsights } from '../services/cookingInsights.js';
// Các đường dẫn API. `repo` là lớp truy cập CSDL (db.js), tách ra để dễ thay khi kiểm thử.
import { resolve } from 'node:path';

const PROCESSING_LANGUAGES = new Set(['vi','en','zh']);
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);


export function registerTranslationRoutes(app, { repo, adminReady, translator, throttle, auth }) {
  // Translation runs on our own Ollama instance, not MyMemory.
  // Rate-limited at request level and payload bounded to protect local model capacity.
  const translationRequests = new Map();
  app.post('/api/translate', throttle('translate', 40, 60 * 1000), auth, wrap(async (req, res) => {
    const { text, from, to } = req.body || {};
    if (typeof text !== 'string' || !text.trim() || text.length > 4000 ||
        !PROCESSING_LANGUAGES.has(from) || !PROCESSING_LANGUAGES.has(to))
      return res.status(400).json({ code: 'invalid' });
    const key = String(req.currentUser.id || req.currentUser.email);
    const current = translationRequests.get(key) || 0;
    if (current >= 2) return res.status(429).json({ code: 'busy' });
    translationRequests.set(key, current + 1);
    try {
      const translatedText = await translator.translate(text, from, to);
      return res.json({ translatedText, ...cookingInsights([{text}], from) });
    } catch (e) {
      const code = ['model_missing', 'timeout', 'unavailable', 'empty'].includes(e.code) ? e.code : 'server';
      return res.status(code === 'unavailable' || code === 'model_missing' ? 503 : 502).json({ code });
    } finally {
      if (current) translationRequests.set(key, current);
      else translationRequests.delete(key);
    }
  }));

  app.get('/api/health', wrap(async (req, res) => {
    try {
      await repo.ping();
      res.status(adminReady ? 200 : 503).json({ ok: Boolean(adminReady), db: true, adminReady: Boolean(adminReady) });
    } catch (e) {
      res.status(503).json({ ok: false, db: false });
    }
  }));

  // Độc lập với /api/health: nếu model đang tải, login và DB vẫn sẵn sàng.
  app.get('/api/health/translation', wrap(async (_req, res) => {
    const status = await translator.status();
    res.status(status.reachable && status.modelReady ? 200 : 503).json({
      ok: status.reachable && status.modelReady, ...status,
    });
  }));

}
