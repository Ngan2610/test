import { cookingInsights } from '../services/cookingInsights.js';
// Các đường dẫn API. `repo` là lớp truy cập CSDL (db.js), tách ra để dễ thay khi kiểm thử.
import { mkdir, rename, unlink, stat, rm } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { join, resolve, sep } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import { randomUUID } from 'node:crypto';
import { produceVoiceover } from '../audioExport.js';
import { createProcessingJob, accessibleJob, matchingAsset } from '../services/jobService.js';
import { saveJobPayload } from '../services/jobPayload.js';

const VALID_LANG = /^[a-z]{2,8}$/;
const PROCESSING_LANGUAGES = new Set(['vi','en','zh']);
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);


export function registerVideoRoutes(app, { repo, UPLOAD_DIR, maxUploadBytes, auth, customerOnly, videoFor }) {
  // ---- Video do khách tải lên; lưu file ở volume, metadata và kết quả ở SQL ----
  app.get('/api/videos', auth, wrap(async (req, res) => {
    res.json({ videos: await repo.userVideos(req.currentUser.email) });
  }));
  app.post('/api/videos', customerOnly, wrap(async (req, res) => {
    const b = req.body || {};
    const title = String(b.title || '').trim();
    const fileName = String(b.fileName || '').trim();
    const size = Number(b.size);
    const mimeType = String(b.mimeType || '').trim().toLowerCase();
    const originalLanguage = String(b.originalLanguage || '').trim();
    const requestId = req.get('X-Idempotency-Key') || null;
    if (requestId && !/^[0-9a-f-]{36}$/i.test(requestId)) return res.status(400).json({code:'invalid_idempotency_key'});
    if (!title || title.length > 200 || !fileName || fileName.length > 255 ||
        !Number.isSafeInteger(size) || size <= 0 || size > maxUploadBytes ||
        !['video/mp4','video/webm','video/quicktime'].includes(mimeType) || !VALID_LANG.test(originalLanguage))
      return res.status(400).json({ code: 'invalid' });
    const record = await repo.createVideo(req.currentUser.email, { title, fileName, size, mimeType, originalLanguage, requestId });
    if (!record) return res.status(404).json({ code: 'not_found' });
    res.status(record.reused ? 200 : 201).json({ video: record });
  }));
  // Cancel only metadata without uploaded bytes; return the reserved upload credit.
  app.post('/api/videos/:id/cancel', customerOnly, wrap(async(req,res)=>{
    const id=Number(req.params.id);
    if (!Number.isSafeInteger(id) || id<=0) return res.status(400).json({code:'invalid'});
    if (!await repo.cancelUnfinishedVideo(id,req.currentUser.id))
      return res.status(409).json({code:'not_cancellable'});
    res.json({ok:true});
  }));
  app.put('/api/videos/:id/file', customerOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res);
    if (!video) return;
    if (video.videoUrl) return res.status(409).json({ code: 'exists' });
    if (req.get('content-type')?.split(';')[0] !== 'application/octet-stream')
      return res.status(415).json({ code: 'invalid' });
    if (Number(req.get('content-length')) > maxUploadBytes) return res.status(413).json({ code: 'too_large' });
    await mkdir(UPLOAD_DIR, { recursive: true });
    const key = `${video.id}-${randomUUID()}.bin`;
    const tempPath = join(UPLOAD_DIR, key + '.part');
    const finalPath = join(UPLOAD_DIR, key);
    let length = 0;
    const counter = new Transform({ transform(chunk, enc, cb) {
      length += chunk.length;
      cb(length > maxUploadBytes ? new Error('too_large') : null, chunk);
    }});
    try {
      await pipeline(req, counter, createWriteStream(tempPath, { flags: 'wx' }));
      if (length !== Number(video.size)) throw new Error('size_mismatch');
      await rename(tempPath, finalPath);
      await repo.setVideoFile(video.id, finalPath);
      res.status(201).json({ ok: true, id: video.id });
    } catch (err) {
      await unlink(tempPath).catch(() => {});
      await unlink(finalPath).catch(() => {});
      if (err.message === 'too_large' || err.message === 'size_mismatch')
        return res.status(err.message === 'too_large' ? 413 : 400).json({ code: err.message });
      throw err;
    }
  }));
  app.get('/api/videos/:id/file', auth, wrap(async (req, res) => {
    const video = await videoFor(req, res);
    if (!video) return;
    if (!video.videoUrl) return res.status(404).json({ code: 'not_found' });
    // Chỉ mở đường dẫn đã sinh bên trong volume.
    if (!video.videoUrl.startsWith(UPLOAD_DIR + sep)) return res.status(403).json({ code: 'forbidden' });
    const size = await stat(video.videoUrl).catch(() => null);
    if (!size) return res.status(404).json({ code: 'not_found' });
    res.type(video.mimeType).sendFile(video.videoUrl);
  }));
  app.post('/api/videos/:id/results', customerOnly, wrap(async (req, res) => {
    const video = await videoFor(req, res);
    if (!video) return;
    const originalLanguage = req.body?.originalLanguage;
    if (originalLanguage != null && originalLanguage !== video.originalLanguage) return res.status(400).json({code:'invalid_source_language'});
    const segments = req.body?.segments;
    if (!Array.isArray(segments) || !segments.length || segments.length > 2000 ||
        segments.some(s => !s || typeof s !== 'object' || !Object.keys(s).some(k => VALID_LANG.test(k)) ||
          [...PROCESSING_LANGUAGES].some(k => s[k] != null && (typeof s[k] !== 'string' || s[k].length > 4000)) ||
          ((s.start != null || s.end != null) && (!Number.isFinite(s.start) || !Number.isFinite(s.end) || s.start < 0 || s.end <= s.start))))
      return res.status(400).json({ code: 'invalid' });
    if (segments.some((s,i) => i > 0 && s.start != null && segments[i-1].end != null && s.start < segments[i-1].end))
      return res.status(400).json({ code:'invalid' });
    const langs = [...new Set(segments.flatMap(s => Object.keys(s).filter(k => PROCESSING_LANGUAGES.has(k) && typeof s[k] === 'string')))];
    if (!langs.length) return res.status(400).json({ code: 'invalid' });
    const result = { narrations: {}, subtitles: {} };
    for (const lang of langs) {
      const content = JSON.stringify(segments.filter(s => s[lang] != null).map(s => ({ text: s[lang], start: s.start ?? null, end: s.end ?? null })));
      result.narrations[lang] = content;
      result.subtitles[lang] = content;
    }
    await repo.saveVideoResult(video.id, 'completed', result, req.currentUser.email, originalLanguage);
    res.json({ ok: true, languages: langs });
  }));
  app.get('/api/videos/:id/insights', auth, wrap(async (req,res) => {
    const video=await videoFor(req,res); if (!video) return;
    const results=await repo.videoResults(video.id);
    const row=results.narrations?.find(x=>x.language===video.originalLanguage);
    let lines=[]; try { lines=JSON.parse(row?.content || '[]'); } catch { /* no transcript */ }
    res.json(cookingInsights(lines,video.originalLanguage));
  }));
  app.get('/api/videos/:id/results', auth, wrap(async (req, res) => {
    const video = await videoFor(req, res);
    if (!video) return;
    res.json(await repo.videoResults(video.id));
  }));
  // SQL-backed pipeline accepts saved timelines or server STT for raw uploads.
  app.post('/api/jobs/process-video', customerOnly, wrap(async (req,res) => {
    const id = Number(req.body?.videoId);
    if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({code:'invalid_video_id'});
    const video = await repo.getVideo(id);
    if (!video || video.userEmail !== req.currentUser.email) return res.status(404).json({code:'not_found'});
    if (!await stat(video.videoUrl || '').catch(()=>null)) return res.status(409).json({code:'video_file_missing'});
    const result = await createProcessingJob(repo,video,req.currentUser,req.body,UPLOAD_DIR,
      (jobId,payload)=>saveJobPayload(UPLOAD_DIR,jobId,payload));
    res.status(202).json({ok:true,jobId:result.id,reused:result.reused});
  }));
  app.get('/api/jobs/video/:videoId/latest', customerOnly, wrap(async (req,res) => {
    const id=Number(req.params.videoId);
    if (!Number.isSafeInteger(id) || id<1) return res.status(400).json({code:'invalid_video_id'});
    const job=await repo.latestVideoProcessingJob(id,req.currentUser.id);
    if (!job) return res.status(404).json({code:'job_not_found'});
    res.json({ok:true,job:accessibleJob(job,req.currentUser)});
  }));
  app.get('/api/jobs/:id', auth, wrap(async (req,res) => {
    if (!/^[1-9][0-9]{0,15}$/.test(req.params.id)) return res.status(400).json({code:'invalid'});
    const status = accessibleJob(await repo.getProcessingJob(req.params.id),req.currentUser);
    const assets = await repo.listProcessingAssets(req.params.id);
    const downloadable = assets.map(a=>{
      const match=/^job-\d+-(vi|en|zh|multi)\.(mp3|mp4|srt|vtt)$/.exec(a.path.split(/[\\/]/).pop());
      return match?{language:match[1],format:match[2],size:Number(a.size)}:null;
    }).filter(Boolean);
    res.json({ok:true,job:{...status,assets:downloadable}});
  }));
  app.get('/api/jobs/:id/download/:language/:format', auth, wrap(async (req,res) => {
    if (!/^[1-9][0-9]{0,15}$/.test(req.params.id)) return res.status(400).json({code:'invalid'});
    const job=accessibleJob(await repo.getProcessingJob(req.params.id),req.currentUser,{ownerOnly:true});
    if (job.status!=='completed') return res.status(409).json({code:'job_not_completed'});
    const asset=matchingAsset(await repo.listProcessingAssets(req.params.id),req.params.id,
      req.params.language,req.params.format,UPLOAD_DIR);
    if (!asset || !await stat(asset.path).catch(()=>null)) return res.status(404).json({code:'not_found'});
    res.set('Cache-Control','private, no-store');
    res.download(asset.path,`dubchef-${job.videoId}-${req.params.language}.${req.params.format}`);
  }));
  app.get('/api/languages', wrap(async (req, res) => res.json({ languages: (await repo.languages()).filter(x => x.status === 'active' && PROCESSING_LANGUAGES.has(x.code)) })));

  // Xuất MP3/MP4 thật từ KỊCH BẢN ĐÃ XUẤT BẢN, không dùng speechSynthesis trên trình duyệt.
  // Có giới hạn 1 công việc tại một thời điểm để tránh tăng tải CPU/RAM của máy demo.
  const activeVoiceExports = new Set();
  async function downloadVoiceover(req, res) {
    const video = await videoFor(req, res);
    if (!video) return;
    const language = String(req.params.language || '');
    const format = String(req.params.format || '');
    if (!PROCESSING_LANGUAGES.has(language) || !['mp3','mp4'].includes(format))
      return res.status(400).json({code:'invalid'});
    if (activeVoiceExports.size) return res.status(429).json({code:'export_busy'});
    const media = await repo.mediaDetail('narrations', video.id, language);
    if (!media) return res.status(404).json({code:'narration_not_found'});
    if (media.status !== 'published') return res.status(409).json({code:'narration_not_published'});
    const videoPath = typeof video.videoUrl === 'string' && video.videoUrl.startsWith(UPLOAD_DIR + sep)
      && await stat(video.videoUrl).catch(() => null) ? video.videoUrl : null;
    if (format === 'mp4' && !videoPath) return res.status(409).json({code:'video_file_missing'});
    const key = `${video.id}-${language}`;
    activeVoiceExports.add(key);
    let generated;
    try {
      generated = await produceVoiceover({content:media.content, language, format, sourceVideo:videoPath});
      const fileName = `dubchef-video-${video.id}-${language}-v${media.version}.${format}`;
      res.set('Cache-Control', 'no-store');
      return res.download(generated.output, fileName, async (err) => {
        await rm(generated.directory, {recursive:true, force:true}).catch(() => {});
        if (err && !res.headersSent) res.status(500).json({code:'download_failed'});
      });
    } catch (error) {
      if (generated) await rm(generated.directory, {recursive:true, force:true}).catch(() => {});
      if (error.status) return res.status(error.status).json({code:error.code, ...(error.segment ? {segment:error.segment} : {})});
      throw error;
    } finally { activeVoiceExports.delete(key); }
  }
  app.get('/api/videos/:id/exports', auth, wrap(async (req, res) => {
    const video = await videoFor(req, res);
    if (!video) return;
    const details = await Promise.all([...PROCESSING_LANGUAGES].map(language => repo.mediaDetail('narrations', video.id, language)));
    const available = [...PROCESSING_LANGUAGES].filter((language, index) => details[index]?.status === 'published');
    res.json({languages: available, hasVideo: Boolean(video.videoUrl)});
  }));
  app.get('/api/videos/:id/export/:language/:format', auth, wrap(downloadVoiceover));
  // Admin được xuất bản đã duyệt của mọi video; videoFor cũng xác thực tài khoản SQL.

}
