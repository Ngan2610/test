import { beforeEach,describe,expect,it,vi } from 'vitest';
import { render,screen } from '@testing-library/react';
import { renderAdminComponent } from './adminTestUtils.jsx';
import userEvent from '@testing-library/user-event';
import AdminMediaResults from '../pages/AdminMediaResults.jsx';
import SavedVideo from '../components/SavedVideo.jsx';
import { manageApi,workApi } from '../api/workflows.js';
vi.mock('../api/workflows.js',()=>({manageApi:{mediaIndex:vi.fn(),videos:vi.fn(),languages:vi.fn(),mediaDetail:vi.fn(),mediaHistory:vi.fn(),saveMedia:vi.fn()},workApi:{videoInsights:vi.fn().mockResolvedValue({ingredients:[],steps:[],glossary:[],conversions:[]}),downloadVideo:vi.fn(),videoResults:vi.fn()}}));
beforeEach(()=>{
  vi.clearAllMocks();manageApi.mediaIndex.mockResolvedValue({items:[{id:9,videoId:1,title:'Phở',userEmail:'a@example.com',language:'vi',status:'draft',version:2}]});
  manageApi.videos.mockResolvedValue({videos:[{id:1,title:'Phở'}]});manageApi.languages.mockResolvedValue({languages:[{code:'vi',status:'active'}]});
  manageApi.mediaDetail.mockResolvedValue({item:{videoId:1,language:'vi',version:2,status:'draft',content:JSON.stringify([{text:'Đun nước',start:0,end:3}])}});
  manageApi.mediaHistory.mockResolvedValue({history:[{id:1,version:2,status:'draft',editor:'admin@example.com',changedAt:'2026-11-11T00:00:00Z'}]});manageApi.saveMedia.mockResolvedValue({version:3});
});
describe('Current Admin media workflow',()=>{
 it('opens SQL content and saves exact video language version and timeline',async()=>{
  const user=userEvent.setup();renderAdminComponent(<AdminMediaResults kind="narrations"/>);
  await user.click(await screen.findByRole('button',{name:'Mở kịch bản'}));
  expect(await screen.findByDisplayValue('Đun nước')).toBeInTheDocument();expect(screen.getByText('admin@example.com')).toBeInTheDocument();
  await user.clear(screen.getByLabelText('Nội dung dòng 1'));await user.type(screen.getByLabelText('Nội dung dòng 1'),'Lời mới');
  await user.click(screen.getByRole('button',{name:'Lưu vào SQL Server'}));
  expect(manageApi.saveMedia).toHaveBeenCalledWith('narrations',1,'vi',{version:2,status:'draft',lines:[{start:0,end:3,text:'Lời mới'}]});
 });
 it('invalid timing never sends a save request',async()=>{
  const user=userEvent.setup();renderAdminComponent(<AdminMediaResults kind="subtitles"/>);await user.click(await screen.findByRole('button',{name:'Biên tập phụ đề'}));
  const end=await screen.findByLabelText('Kết thúc dòng 1');await user.clear(end);await user.type(end,'0');
  await user.click(screen.getByRole('button',{name:'Lưu vào SQL Server'}));expect(manageApi.saveMedia).not.toHaveBeenCalled();
  expect(screen.getByRole('status')).toHaveTextContent('không chồng lấn');
 });
 it('version conflict preserves the unsaved editor and explains reload',async()=>{
  manageApi.saveMedia.mockRejectedValue(Object.assign(new Error('conflict'),{code:'conflict'}));
  const user=userEvent.setup();renderAdminComponent(<AdminMediaResults kind="subtitles"/>);await user.click(await screen.findByRole('button',{name:'Biên tập phụ đề'}));
  await screen.findByLabelText('Nội dung dòng 1');await user.click(screen.getByRole('button',{name:'Lưu vào SQL Server'}));
  expect(await screen.findByText(/Bản ghi đã được người khác sửa/)).toBeInTheDocument();expect(screen.getByLabelText('Nội dung dòng 1')).toHaveValue('Đun nước');
 });
 it('subtitle editing shows timeline preview and subtitle file exports, but no voice panel',async()=>{
  const user=userEvent.setup();renderAdminComponent(<AdminMediaResults kind="subtitles"/>);
  await user.click(await screen.findByRole('button',{name:'Biên tập phụ đề'}));
  expect(screen.getByRole('region',{name:'Xem trước phụ đề theo thời gian'})).toBeInTheDocument();
  expect(screen.getByRole('button',{name:'Xuất SRT'})).toBeInTheDocument();
  expect(screen.getByRole('button',{name:'Xuất VTT'})).toBeInTheDocument();
  expect(screen.queryByRole('button',{name:'Nghe toàn bộ'})).not.toBeInTheDocument();
 });
 it('narration editing shows speech preview and script instead of subtitle exports',async()=>{
  const user=userEvent.setup();renderAdminComponent(<AdminMediaResults kind="narrations"/>);
  await user.click(await screen.findByRole('button',{name:'Mở kịch bản'}));
  expect(screen.getByRole('button',{name:'Nghe toàn bộ'})).toBeInTheDocument();
  expect(screen.getByRole('button',{name:'Xuất kịch bản TXT'})).toBeInTheDocument();
  expect(screen.getByLabelText('Tốc độ nghe thử')).toBeInTheDocument();
  expect(screen.queryByRole('button',{name:'Xuất SRT'})).not.toBeInTheDocument();
 });
 it('saved viewer loads protected file and SQL subtitles, reports download failure',async()=>{
  workApi.downloadVideo.mockRejectedValue(new Error('offline'));workApi.videoResults.mockResolvedValue({subtitles:[]});
  render(<SavedVideo video={{id:1,title:'Phở'}} onClose={()=>{}}/>);
  expect(await screen.findByRole('alert')).toHaveTextContent('Không mở được');
  expect(workApi.downloadVideo).toHaveBeenCalledWith(1);expect(workApi.videoResults).toHaveBeenCalledWith(1);
 });
});
